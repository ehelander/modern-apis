module.exports = {
    "extends": "airbnb-base",
    "rules": {
        "comma-dangle": 0
    },
    "env": {"node": true, "mocha": true}
};