plugins { java }
