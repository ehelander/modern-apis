tasks.register("hello") {
  doLast {
    println("Hello Gradle")
  }
}
