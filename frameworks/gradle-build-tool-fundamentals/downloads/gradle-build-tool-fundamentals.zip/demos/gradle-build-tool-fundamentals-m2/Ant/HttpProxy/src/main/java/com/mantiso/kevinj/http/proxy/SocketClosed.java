package com.mantiso.kevinj.http.proxy;

/**
 * Created by kevin on 04/06/2015.
 */
public class SocketClosed extends Throwable {

    public SocketClosed(String message) {
        super(message);
    }
}
