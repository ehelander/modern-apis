plugins {
    `java-library`
}


