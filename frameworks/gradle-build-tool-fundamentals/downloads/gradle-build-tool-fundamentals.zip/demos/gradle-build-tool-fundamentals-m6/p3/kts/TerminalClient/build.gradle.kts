apply (plugin= "application")

version = "1.0-SNAPSHOT"

