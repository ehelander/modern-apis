plugins {
    `java-library`
}

dependencies {
    api ("org.apache.httpcomponents:httpcore:4.4.13")
}

