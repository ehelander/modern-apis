package com.pluralsight.repository;

/**
 * Created by kevin on 30/06/2015.
 */
public abstract class BaseRepository<T> implements Repository<T> {
}
