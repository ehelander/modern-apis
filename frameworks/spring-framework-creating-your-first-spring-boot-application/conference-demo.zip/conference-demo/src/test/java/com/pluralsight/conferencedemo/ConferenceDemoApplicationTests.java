package com.pluralsight.conferencedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConferenceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
